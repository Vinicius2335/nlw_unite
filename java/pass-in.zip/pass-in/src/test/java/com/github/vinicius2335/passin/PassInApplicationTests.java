package com.github.vinicius2335.passin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassInApplicationTests {

	@Test
	void contextLoads() {
	}

}
