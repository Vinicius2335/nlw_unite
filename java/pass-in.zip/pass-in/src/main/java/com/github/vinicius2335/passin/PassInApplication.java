package com.github.vinicius2335.passin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassInApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassInApplication.class, args);
	}

}
